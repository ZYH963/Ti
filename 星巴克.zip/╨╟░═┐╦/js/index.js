(function() {
    var nr = "直达顶部";
    var fanhui = $('<div class="back"></div>').appendTo($("body")).text(nr).click(function() {
        $("html, body").animate({ scrollTop: 0 }, 120);
    })
    aa = function() {
        var st = $(document).scrollTop(), winh = $(window).height();
        (st > 0)? fanhui.show(): fanhui.hide();    
    };

    $(window).bind("scroll",aa);
    
    $(function() {aa(); });
})();
//弹窗
      window.onload=function(){
            var box=document.getElementById("box");
      box.onmouseover = function(){
        move(10)
      };
      box.onmouseout = function(){
        move(-10)
      };
    }
    var timer;
    function move(spd){
      clearInterval(timer);
      var box = document.getElementById('box');
        timer = setInterval(function(){
        //console.log(box.offsetLeft);
       
        if(box.offsetLeft == -100+10*spd){//
          // console.log(spd);
          // console.log(box.offsetLeft);
          clearInterval(timer);
        }else{
          // console.log(spd);
          // console.log(box.offsetLeft+spd);
          box.style.left=box.offsetLeft+spd+'px';
        }
      },20);
    }  

    //添加
    $("#box").append('<div class="zz"><img src="images/qq.png" class="images">QQ<br><img src="images/微博.png" class="images">微博<br><img src="images/微信.png" class="images">微信<br><img src="images/QQ 空间.png" class="images">空间<br></div>');
//图片切换(初始进入切换有问题)
$(function() {
    var i = 0; // 当前显示的图片索引
    var timer; // 定时器
    var delay = 2000; // 图片自动切换的间隔时间
    var width = 1063; // 每张图片的宽度
    var speed = 500; // 动画时间
// 复制列表中的第一个图片，追加到列表最后，设置的宽度为图片张数 * 图片宽度
var firstimg = $('.img2 img').first().clone();
//console.log($('img2 img'))
// console.log(firstimg);
    $('.img2').append(firstimg).width($('.img2 img').length * width );

    // 1. 设置周期计时器，实现图片自动切换
     timer = setInterval(imgChange, delay);

    // 2. 鼠标移入，暂停自动播放，移出，开始自动播放
    $('.img1').hover(function() {
        clearInterval(timer);
    }, function() {
        timer = setInterval(imgChange, delay);
    });
   
    // 自动切换图片
    function imgChange() {
        ++i;
        isCrack();
        
    }
    // // 5. 向右箭头
    // $('.tu7 next').click(function() {
    //     imgChange()
    // });
    // 无缝轮播
    function isCrack() {
        if (i == $('.img2 img').length) {
            i = 1;
            $('.img2').css({ left: 0 });
        }
        $('.img2').stop().animate({ left: -i * width }, speed);
        console.log({left: -i * width });
    }
  });